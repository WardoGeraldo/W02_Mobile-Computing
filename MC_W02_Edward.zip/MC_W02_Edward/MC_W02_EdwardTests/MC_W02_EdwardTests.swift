//
//  MC_W02_EdwardTests.swift
//  MC_W02_EdwardTests
//
//  Created by student on 18/09/25.
//

import Testing
@testable import MC_W02_Edward

struct MC_W02_EdwardTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
